import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { authApi } from '../../api/endpoints.js';
import { useAuth } from '../../context/AuthContext.jsx';
import AuthLayout from '../../components/layout/AuthLayout.jsx';
import Field from '../../components/common/Field.jsx';
import ErrorBox from '../../components/common/ErrorBox.jsx';

export default function AdminLoginPage() {
  const { isAuthed, user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // Already signed in as admin? Go straight to the admin area (checked once, on arrival).
  useEffect(() => {
    if (isAuthed && user.role === 'admin') navigate('/admin', { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      login(await authApi.adminLogin({ email, password }));
      navigate('/admin', { replace: true });
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      badge="Admin"
      heading="Station control room."
      points={['Add and update charging stations', 'Set prices and slot availability', 'Manage users and monitor activity']}
      footnote="Admin sessions expire after 2 hours."
    >
      <h2>Administrator sign in</h2>
      <form onSubmit={submit} noValidate>
        <ErrorBox message={error} />
        <Field label="Admin email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" required /></Field>
        <Field label="Password"><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required /></Field>
        <button className="btn spark block" type="submit" disabled={busy}>Sign in to admin</button>
      </form>
      <p className="small" style={{ marginTop: 24 }}><Link to="/login">Back to driver sign in</Link></p>
    </AuthLayout>
  );
}
