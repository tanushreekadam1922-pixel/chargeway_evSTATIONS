import { adminApi } from '../../api/endpoints.js';
import useLoader from '../../hooks/useLoader.js';
import ActivityList from '../../components/admin/ActivityList.jsx';
import Loading from '../../components/common/Loading.jsx';
import ErrorBox from '../../components/common/ErrorBox.jsx';

export default function AdminActivity() {
  const { data, error } = useLoader(() => adminApi.activity(), { pollMs: 20000 });
  if (error && !data) return <ErrorBox message={error} />;
  if (!data) return <Loading />;
  return <ActivityList title="Activity log" rows={data.activity} />;
}
