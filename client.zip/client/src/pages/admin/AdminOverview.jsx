import { adminApi } from '../../api/endpoints.js';
import useLoader from '../../hooks/useLoader.js';
import StatsOverview from '../../components/admin/StatsOverview.jsx';
import LiveSessions from '../../components/admin/LiveSessions.jsx';
import ActivityList from '../../components/admin/ActivityList.jsx';
import Loading from '../../components/common/Loading.jsx';
import ErrorBox from '../../components/common/ErrorBox.jsx';

export default function AdminOverview() {
  const { data, error } = useLoader(() => Promise.all([adminApi.stats(), adminApi.activity()]), { pollMs: 20000 });
  if (error && !data) return <ErrorBox message={error} />;
  if (!data) return <Loading />;
  const [stats, activity] = data;

  return (
    <section>
      <StatsOverview stats={stats} />
      <div className="grid g2" style={{ marginTop: 24, alignItems: 'start' }}>
        <LiveSessions sessions={activity.active_sessions} />
        <ActivityList rows={activity.activity.slice(0, 8)} />
      </div>
    </section>
  );
}
