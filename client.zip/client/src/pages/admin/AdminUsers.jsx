import { adminApi } from '../../api/endpoints.js';
import useLoader from '../../hooks/useLoader.js';
import UserTable from '../../components/admin/UserTable.jsx';
import Loading from '../../components/common/Loading.jsx';
import ErrorBox from '../../components/common/ErrorBox.jsx';

export default function AdminUsers() {
  const { data, error, reload } = useLoader(() => adminApi.users(), { pollMs: 30000 });
  if (error && !data) return <ErrorBox message={error} />;
  if (!data) return <Loading />;

  return (
    <section className="card">
      <h2>Registered users ({data.users.length})</h2>
      <UserTable users={data.users} onChanged={reload} />
    </section>
  );
}
