import { useState } from 'react';
import { adminApi } from '../../api/endpoints.js';
import useLoader from '../../hooks/useLoader.js';
import AdminStationCard from '../../components/admin/AdminStationCard.jsx';
import StationFormModal from '../../components/admin/StationFormModal.jsx';
import QrModal from '../../components/admin/QrModal.jsx';
import Loading from '../../components/common/Loading.jsx';
import ErrorBox from '../../components/common/ErrorBox.jsx';

export default function AdminStations() {
  const [editing, setEditing] = useState(undefined);   // undefined = closed, null = new station, object = edit
  const [qrFor, setQrFor] = useState(null);
  const modalOpen = editing !== undefined || qrFor !== null;

  // Pause the auto-refresh while a dialog is open.
  const { data, error, reload } = useLoader(() => adminApi.stations(), { pollMs: modalOpen ? null : 20000 });
  if (error && !data) return <ErrorBox message={error} />;
  if (!data) return <Loading />;
  const { stations } = data;

  return (
    <section>
      <div className="row between" style={{ marginBottom: 16 }}>
        <h2 style={{ margin: 0 }}>Charging stations ({stations.length})</h2>
        <button className="btn spark" onClick={() => setEditing(null)}>Add station</button>
      </div>

      {stations.length ? stations.map((s) => (
        <AdminStationCard key={s.id} station={s} onChanged={reload} onEdit={setEditing} onQr={setQrFor} />
      )) : (
        <div className="card"><p className="muted">No stations yet. Add your first one.</p></div>
      )}

      {editing !== undefined && (
        <StationFormModal
          station={editing} stations={stations}
          onClose={() => setEditing(undefined)}
          onSaved={() => { setEditing(undefined); reload(); }}
        />
      )}
      {qrFor && <QrModal station={qrFor} onClose={() => setQrFor(null)} />}
    </section>
  );
}
