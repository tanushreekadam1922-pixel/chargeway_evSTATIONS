import { useState } from 'react';
import { authApi } from '../../api/endpoints.js';
import Field from '../common/Field.jsx';
import ErrorBox from '../common/ErrorBox.jsx';

export default function RegisterForm({ onSuccess }) {
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) return setError('Passwords do not match.');
    setBusy(true);
    try {
      const { name, email, phone, password } = form;
      onSuccess(await authApi.register({ name, email, phone, password }));
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} noValidate>
      <ErrorBox message={error} />
      <Field label="Full name"><input value={form.name} onChange={set('name')} autoComplete="name" required /></Field>
      <Field label="Email"><input type="email" value={form.email} onChange={set('email')} autoComplete="email" required /></Field>
      <Field label="Phone (optional)"><input type="tel" value={form.phone} onChange={set('phone')} autoComplete="tel" /></Field>
      <Field label="Password" hint="At least 8 characters, with a letter and a number.">
        <input type="password" value={form.password} onChange={set('password')} autoComplete="new-password" required />
      </Field>
      <Field label="Confirm password">
        <input type="password" value={form.confirm} onChange={set('confirm')} autoComplete="new-password" required />
      </Field>
      <button className="btn spark block" type="submit" disabled={busy}>Create account</button>
    </form>
  );
}
