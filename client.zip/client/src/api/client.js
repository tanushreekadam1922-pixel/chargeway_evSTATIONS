// Low-level fetch wrapper + token storage. Every backend call goes through api().

const TOKEN_KEY = 'cw_token';
const USER_KEY = 'cw_user';

export const storage = {
  getToken() { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } },
  getUser() { try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch { return null; } },
  save({ token, user }) {
    try { localStorage.setItem(TOKEN_KEY, token); localStorage.setItem(USER_KEY, JSON.stringify(user)); } catch { /* storage blocked */ }
  },
  clear() {
    try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); } catch { /* storage blocked */ }
  },
};

// AuthContext registers a callback here so an expired token signs the user out of the UI.
let onUnauthorized = null;
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

/** Calls the backend and returns parsed JSON. Throws Error(message) using the server's friendly message. */
export async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = storage.getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new Error('Cannot reach the server. Check that the backend is running on port 3000.');
  }

  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }

  if (res.status === 401 && token) {          // token expired, or the account was removed or blocked
    storage.clear();
    if (onUnauthorized) onUnauthorized();
    throw new Error('Session expired. Please sign in again.');
  }
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}
