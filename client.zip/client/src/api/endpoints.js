// One function per backend endpoint, grouped by who uses it. Components never build URLs themselves.
import { api } from './client.js';

const send = (method) => (path, body) => api(path, { method, body });
const post = send('POST');
const put = send('PUT');
const del = send('DELETE');

export const authApi = {
  login: (body) => post('/api/auth/login', body),
  register: (body) => post('/api/auth/register', body),
  adminLogin: (body) => post('/api/admin/login', body),
};

export const userApi = {
  me: () => api('/api/me'),
  config: () => api('/api/config'),
  updateProfile: (body) => put('/api/me', body),
  changePassword: (body) => put('/api/me/password', body),
  saveVehicle: (body) => put('/api/vehicle', body),
  dashboard: () => api('/api/dashboard'),
  history: () => api('/api/charging/history'),
};

export const stationApi = {
  nearby: (lat, lng, radius) => api(`/api/stations/nearby?lat=${lat}&lng=${lng}&radius=${radius}`),
  get: (id) => api(`/api/stations/${id}`),
  startCharging: (body) => post('/api/charging/start', body),
  finishCharging: () => post('/api/charging/finish', {}),
};

export const adminApi = {
  stats: () => api('/api/admin/stats'),
  activity: () => api('/api/admin/activity'),
  stations: () => api('/api/admin/stations'),
  addStation: (body) => post('/api/admin/stations', body),
  updateStation: (id, body) => put(`/api/admin/stations/${id}`, body),
  setStationStatus: (id, status) => put(`/api/admin/stations/${id}/status`, { status }),
  setPrice: (id, price) => put(`/api/admin/stations/${id}/price`, { price_per_kwh: price }),
  deleteStation: (id) => del(`/api/admin/stations/${id}`),
  addSlot: (stationId) => post(`/api/admin/stations/${stationId}/slots`, {}),
  setSlotStatus: (slotId, status) => put(`/api/admin/slots/${slotId}`, { status }),
  deleteSlot: (slotId) => del(`/api/admin/slots/${slotId}`),
  users: () => api('/api/admin/users'),
  setUserStatus: (id, status) => put(`/api/admin/users/${id}`, { status }),
  deleteUser: (id) => del(`/api/admin/users/${id}`),
};
